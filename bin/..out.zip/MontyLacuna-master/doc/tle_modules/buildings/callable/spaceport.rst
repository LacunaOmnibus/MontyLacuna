Spaceport
=========

Any method that requires a ship type needs something from the **System** 
column in :ref:`ship_translations`.

.. automodule:: lacuna.buildings.callable.spaceport
    :members:
    :undoc-members:
    :show-inheritance:
