Capitol
=======

.. automodule:: lacuna.buildings.callable.capitol
    :members:
    :undoc-members:
    :show-inheritance:
