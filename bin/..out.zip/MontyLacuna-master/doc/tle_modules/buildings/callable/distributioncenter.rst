Distribution Center
===================

.. automodule:: lacuna.buildings.callable.distributioncenter
    :members:
    :undoc-members:
    :show-inheritance:
