Mining Ministry
===============

.. automodule:: lacuna.buildings.callable.miningministry
    :members:
    :undoc-members:
    :show-inheritance:
