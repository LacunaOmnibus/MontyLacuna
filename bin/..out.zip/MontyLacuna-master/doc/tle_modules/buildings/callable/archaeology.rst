Archaeology Ministry
====================

.. automodule:: lacuna.buildings.callable.archaeology
    :members:
    :undoc-members:
    :show-inheritance:
