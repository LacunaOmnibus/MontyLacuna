Security Ministry
=================

.. automodule:: lacuna.buildings.callable.security
    :members:
    :undoc-members:
    :show-inheritance:
