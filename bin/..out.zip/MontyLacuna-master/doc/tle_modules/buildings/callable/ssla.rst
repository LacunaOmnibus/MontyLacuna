Space Station Lab (A)
=====================

Although the Space Station Lab consists of four parts, part A, the upper-left 
corner, is the only one that you can actually use.

.. automodule:: lacuna.buildings.callable.ssla
    :members:
    :undoc-members:
    :show-inheritance:
