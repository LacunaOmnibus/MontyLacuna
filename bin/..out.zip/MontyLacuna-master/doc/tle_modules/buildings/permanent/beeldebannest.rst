
Beeldeban Nest (beetle)
=======================

.. automodule:: lacuna.buildings.permanent.beeldebannest
    :members:
    :undoc-members:
    :show-inheritance:
