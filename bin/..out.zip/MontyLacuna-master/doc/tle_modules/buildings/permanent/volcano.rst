
Volcano
=======

.. automodule:: lacuna.buildings.permanent.volcano
    :members:
    :undoc-members:
    :show-inheritance:
