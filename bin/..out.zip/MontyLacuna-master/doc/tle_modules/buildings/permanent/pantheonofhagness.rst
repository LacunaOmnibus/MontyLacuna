
Pantheon of Hagness
===================

.. automodule:: lacuna.buildings.permanent.pantheonofhagness
    :members:
    :undoc-members:
    :show-inheritance:
