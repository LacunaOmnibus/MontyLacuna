
Oracle of Anid
==============

.. automodule:: lacuna.buildings.permanent.oracleofanid
    :members:
    :undoc-members:
    :show-inheritance:
