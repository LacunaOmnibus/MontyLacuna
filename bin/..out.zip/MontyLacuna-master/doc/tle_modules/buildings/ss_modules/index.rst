.. _ss_modules:

Space Station Modules
=====================

All space station modules inherit from :class:`lacuna.building.MyBuilding`.

.. toctree::
   :maxdepth: 1

   artmuseum
   culinaryinstitute
   ibs
   operahouse
   parliament
   policestation
   stationcommand
   warehouse

