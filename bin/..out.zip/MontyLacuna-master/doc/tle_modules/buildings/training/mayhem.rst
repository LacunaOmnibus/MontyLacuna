
Mayhem Training
===============

.. automodule:: lacuna.buildings.training.mayhemtraining
    :members:
    :undoc-members:
    :show-inheritance:
