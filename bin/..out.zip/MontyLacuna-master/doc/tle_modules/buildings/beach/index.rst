.. _beach_modules:

Beach Modules
=====================

beach1
-----------------------------

.. automodule:: lacuna.buildings.beach.beach1
    :members:
    :undoc-members:
    :show-inheritance:

beach2
-----------------------------

.. automodule:: lacuna.buildings.beach.beach2
    :members:
    :undoc-members:
    :show-inheritance:

beach3
-----------------------------

.. automodule:: lacuna.buildings.beach.beach3
    :members:
    :undoc-members:
    :show-inheritance:

beach4
-----------------------------

.. automodule:: lacuna.buildings.beach.beach4
    :members:
    :undoc-members:
    :show-inheritance:

beach5
-----------------------------

.. automodule:: lacuna.buildings.beach.beach5
    :members:
    :undoc-members:
    :show-inheritance:

beach6
-----------------------------

.. automodule:: lacuna.buildings.beach.beach6
    :members:
    :undoc-members:
    :show-inheritance:

beach7
-----------------------------

.. automodule:: lacuna.buildings.beach.beach7
    :members:
    :undoc-members:
    :show-inheritance:

beach8
-----------------------------

.. automodule:: lacuna.buildings.beach.beach8
    :members:
    :undoc-members:
    :show-inheritance:

beach9
-----------------------------

.. automodule:: lacuna.buildings.beach.beach9
    :members:
    :undoc-members:
    :show-inheritance:

beach10
-----------------------------

.. automodule:: lacuna.buildings.beach.beach10
    :members:
    :undoc-members:
    :show-inheritance:

beach11
-----------------------------

.. automodule:: lacuna.buildings.beach.beach11
    :members:
    :undoc-members:
    :show-inheritance:

beach12
-----------------------------

.. automodule:: lacuna.buildings.beach.beach12
    :members:
    :undoc-members:
    :show-inheritance:

beach13
-----------------------------

.. automodule:: lacuna.buildings.beach.beach13
    :members:
    :undoc-members:
    :show-inheritance:

