
Recall All Ships
================

Recall all defending or orbiting ships from a single planet.

All you have to specify is the name of the planet to pull ships back to::

    >>> python bin/recall_all_ships.py Earth

For complete help, see the script's help documentation:

    >>> python bin/recall_all_ships.py -h

.. autoclass:: lacuna.binutils.librecall_all_ships.RecallShips
   :members:
   :show-inheritance:

