Mission Command
===============

.. automodule:: lacuna.buildings.callable.missioncommand
    :members:
    :undoc-members:
    :show-inheritance:
