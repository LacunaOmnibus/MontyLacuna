
.. _intmin:

Intelligence Ministry
=====================

.. automodule:: lacuna.buildings.callable.intelligence
    :members:
    :undoc-members:
    :show-inheritance:
