.. _bldgs_methods:

Miscellaneous Buildings with Methods
====================================

These have the methods available to all buildings, but they each also have 
their own methods.

.. toctree::
   :maxdepth: 2

   archaeology
   capitol
   development
   distributioncenter
   embassy
   entertainment
   geneticslab
   intelligence
   mercenariesguild
   miningministry
   missioncommand
   network19
   observatory
   park
   planetarycommand
   security
   shipyard
   spaceport
   ssla
   themepark
   trade
   transporter

