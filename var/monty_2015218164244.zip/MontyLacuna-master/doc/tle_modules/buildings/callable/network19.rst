Network 19
==========

.. automodule:: lacuna.buildings.callable.network19
    :members:
    :undoc-members:
    :show-inheritance:
