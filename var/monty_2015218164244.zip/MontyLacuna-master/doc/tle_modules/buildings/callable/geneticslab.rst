Genetics Lab
============

.. automodule:: lacuna.buildings.callable.geneticslab
    :members:
    :undoc-members:
    :show-inheritance:
