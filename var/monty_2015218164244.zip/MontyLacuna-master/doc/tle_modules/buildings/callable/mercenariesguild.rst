Mercenaries Guild
=================

.. automodule:: lacuna.buildings.callable.mercenariesguild
    :members:
    :undoc-members:
    :show-inheritance:
