
.. _bldg_transporter:

Sub Space Transporter (SST)
===========================

.. automodule:: lacuna.buildings.callable.transporter
    :members:
    :undoc-members:
    :show-inheritance:
