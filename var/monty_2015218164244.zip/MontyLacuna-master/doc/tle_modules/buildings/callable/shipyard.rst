Shipyard
========

.. automodule:: lacuna.buildings.callable.shipyard
    :members:
    :undoc-members:
    :show-inheritance:
