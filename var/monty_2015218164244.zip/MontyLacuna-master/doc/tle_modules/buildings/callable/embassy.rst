Embassy
=======

.. automodule:: lacuna.buildings.callable.embassy
    :members:
    :undoc-members:
    :show-inheritance:
