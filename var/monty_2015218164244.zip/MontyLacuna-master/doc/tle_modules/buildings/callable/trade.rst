
.. _bldg_trade:

Trade Ministry (TM)
===================

.. automodule:: lacuna.buildings.callable.trade
    :members:
    :undoc-members:
    :show-inheritance:
