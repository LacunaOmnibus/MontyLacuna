Observatory
===========

.. automodule:: lacuna.buildings.callable.observatory
    :members:
    :undoc-members:
    :show-inheritance:
