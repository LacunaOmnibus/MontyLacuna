
Theft Training
==============

.. automodule:: lacuna.buildings.training.thefttraining
    :members:
    :undoc-members:
    :show-inheritance:
