
Intel Training
==============

.. automodule:: lacuna.buildings.training.inteltraining
    :members:
    :undoc-members:
    :show-inheritance:
