
Politics Training
=================

.. automodule:: lacuna.buildings.training.politicstraining
    :members:
    :undoc-members:
    :show-inheritance:
