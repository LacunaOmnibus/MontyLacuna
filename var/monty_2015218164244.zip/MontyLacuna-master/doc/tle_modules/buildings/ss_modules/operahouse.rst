
Opera House
===========

.. automodule:: lacuna.buildings.ss_modules.operahouse
    :members:
    :undoc-members:
    :show-inheritance:
