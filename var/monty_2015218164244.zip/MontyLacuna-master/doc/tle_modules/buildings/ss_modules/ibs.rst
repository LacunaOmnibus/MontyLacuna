
Interstellar Broadcast System (IBS)
===================================

.. automodule:: lacuna.buildings.ss_modules.ibs
    :members:
    :undoc-members:
    :show-inheritance:
