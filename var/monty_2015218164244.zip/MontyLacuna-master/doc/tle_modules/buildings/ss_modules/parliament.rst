
Parliament
==========

.. automodule:: lacuna.buildings.ss_modules.parliament
    :members:
    :undoc-members:
    :show-inheritance:
