Culinary Institute
==================

.. automodule:: lacuna.buildings.ss_modules.culinaryinstitute
    :members:
    :undoc-members:
    :show-inheritance:
