
Natural Spring
==============

.. automodule:: lacuna.buildings.permanent.naturalspring
    :members:
    :undoc-members:
    :show-inheritance:
