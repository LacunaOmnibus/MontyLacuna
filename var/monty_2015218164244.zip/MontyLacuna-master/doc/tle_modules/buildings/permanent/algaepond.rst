
Algae Pond
==========

.. automodule:: lacuna.buildings.permanent.algaepond
    :members:
    :undoc-members:
    :show-inheritance:
