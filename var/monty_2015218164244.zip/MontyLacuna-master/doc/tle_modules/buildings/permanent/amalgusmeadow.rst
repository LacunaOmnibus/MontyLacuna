
Amalgus Meadow (Beans)
======================

.. automodule:: lacuna.buildings.permanent.amalgusmeadow
    :members:
    :undoc-members:
    :show-inheritance:
