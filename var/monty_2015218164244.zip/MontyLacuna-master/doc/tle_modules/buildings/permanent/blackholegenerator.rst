Black Hole Generator (BHG)
==========================

.. automodule:: lacuna.buildings.permanent.blackholegenerator
    :members:
    :undoc-members:
    :show-inheritance:
