
Temple of the Drajilites
========================

.. automodule:: lacuna.buildings.permanent.templeofthedrajilites
    :members:
    :undoc-members:
    :show-inheritance:
