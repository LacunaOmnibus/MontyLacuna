
Halls of Vrbansk
================
Although this is listed as a building, it's no longer possible to build halls.

.. automodule:: lacuna.buildings.permanent.hallsofvrbansk
    :members:
    :undoc-members:
    :show-inheritance:
