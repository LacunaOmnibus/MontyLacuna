
Subspace Supply Depot (SSD)
===========================

.. automodule:: lacuna.buildings.permanent.subspacesupplydepot
    :members:
    :undoc-members:
    :show-inheritance:
