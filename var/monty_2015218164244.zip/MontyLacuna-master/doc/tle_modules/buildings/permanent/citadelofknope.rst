Citadel of Knope
================

.. automodule:: lacuna.buildings.permanent.citadelofknope
    :members:
    :undoc-members:
    :show-inheritance:
