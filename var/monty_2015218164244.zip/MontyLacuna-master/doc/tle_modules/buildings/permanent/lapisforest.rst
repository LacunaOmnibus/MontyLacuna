
Lapis Forest
============

.. automodule:: lacuna.buildings.permanent.lapisforest
    :members:
    :undoc-members:
    :show-inheritance:
