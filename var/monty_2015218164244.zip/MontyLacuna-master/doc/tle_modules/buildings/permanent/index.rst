.. _permanent:

Permanent (Glyph) Buildings
===========================

.. toctree::
   :maxdepth: 1

   algaepond
   amalgusmeadow
   beeldebannest
   blackholegenerator
   citadelofknope
   crashedshipsite
   dentonbrambles
   essentiavein
   geothermalvent
   gratchsgauntlet
   hallsofvrbansk
   interdimensionalrift
   kalavianruins
   kasternskeep
   lapisforest
   libraryofjith
   malcudfield
   massadshenge
   naturalspring
   oracleofanid
   pantheonofhagness
   subspacesupplydepot
   templeofthedrajilites
   thedillonforge
   volcano
