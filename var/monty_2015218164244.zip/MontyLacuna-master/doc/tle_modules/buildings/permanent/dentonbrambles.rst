
Denton Brambles
===============

.. automodule:: lacuna.buildings.permanent.dentonbrambles
    :members:
    :undoc-members:
    :show-inheritance:
