
Inter Dimensional Rift
======================

.. automodule:: lacuna.buildings.permanent.interdimensionalrift
    :members:
    :undoc-members:
    :show-inheritance:

