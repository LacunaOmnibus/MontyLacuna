
Massads Henge
=============

.. automodule:: lacuna.buildings.permanent.massadshenge
    :members:
    :undoc-members:
    :show-inheritance:
