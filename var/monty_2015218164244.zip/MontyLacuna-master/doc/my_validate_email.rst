my_validate_email
=================

.. automodule:: my_validate_email
    :members:
    :undoc-members:
    :show-inheritance:
