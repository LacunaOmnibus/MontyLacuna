
exceptions
===============

.. automodule:: lacuna.exceptions
   :members:
   :show-inheritance:

